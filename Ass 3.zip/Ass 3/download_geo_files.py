import urllib.request
import os
import gzip

os.makedirs("project/data/raw", exist_ok=True)
os.makedirs("project/data/processed", exist_ok=True)
os.makedirs("project/results/tables", exist_ok=True)
os.makedirs("project/results/figures", exist_ok=True)
os.makedirs("project/notebooks", exist_ok=True)

files = [
    ("GSE52778_All_Sample_FPKM_Matrix.txt.gz", "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE52nnn/GSE52778/suppl/GSE52778_All_Sample_FPKM_Matrix.txt.gz"),
    ("GSE52778_Dex_vs_Untreated_gene_exp.diff.gz", "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE52nnn/GSE52778/suppl/GSE52778_Dex_vs_Untreated_gene_exp.diff.gz")
]

for fname, url in files:
    dest = os.path.join("project/data/raw", fname)
    if not os.path.exists(dest) or os.path.getsize(dest) == 0:
        print(f"Downloading {fname}...")
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as resp, open(dest, "wb") as f:
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                f.write(chunk)
        print(f"Downloaded {fname}: {os.path.getsize(dest)} bytes")
    else:
        print(f"{fname} already exists: {os.path.getsize(dest)} bytes")

# Now let's inspect the first few lines of each file
for fname, _ in files:
    dest = os.path.join("project/data/raw", fname)
    print(f"\n--- First 5 lines of {fname} ---")
    with gzip.open(dest, "rt", encoding="utf-8", errors="ignore") as f:
        for i in range(5):
            print(f.readline().strip())
