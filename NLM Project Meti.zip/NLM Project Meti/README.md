# Project 3: Bioinformatics Application of NLP for Answering Biological Research Questions

## Research Question
> **"What are the predominant molecular pathways, tumor microenvironment factors, and biomarkers driving resistance to immune checkpoint inhibitors (anti-PD-1/CTLA-4) in solid tumors?"**

---

## Deliverables Summary

This repository is organized strictly according to the 3 required project deliverables:

```
NLM Project Meti/
├── 1_Data/
│   ├── pubmed_1000_abstracts.csv          <- 1,000 curated PubMed abstracts with full metadata
│   └── pubmed_1000_abstracts.json         <- JSON-formatted dataset
│
├── 2_Source_Code/
│   ├── main.py                            <- Complete, self-contained Python execution script
│   ├── analysis_notebook.ipynb            <- Interactive Jupyter Notebook demonstration
│   └── requirements.txt                   <- Dependencies list
│
└── 3_Report/
    ├── report.html                        <- Complete, standalone HTML report (open in any browser)
    └── figures/                           <- High-resolution 300 DPI analytical figures
```

---

## 1. Data (`1_Data/`)
- Contains **1,000 peer-reviewed PubMed abstracts** queried from the NCBI Entrez API using boolean filters for cancer immunotherapy resistance.
- Fields: `pmid`, `title`, `abstract`, `journal`, `pub_year`, `authors`, `doi`, `mesh_terms`.

## 2. Source Code (`2_Source_Code/`)
- **Execution Script (`main.py`):**
  - Text normalization & biomedical entity mapping (`anti-pd1`, `tam`, `mdsc`, `tgf_beta`, etc.)
  - NLTK POS-tag lemmatization (WordNet)
  - Domain-specific stopword filtering
  - Document-Term count vectorization
  - Latent Dirichlet Allocation (LDA) topic modeling ($k = 5$ clusters)
  - Topic keyword extraction and probability weights
- **Interactive Notebook (`analysis_notebook.ipynb`):**
  - Walkthrough with markdown explanations and interactive visualizations.
- **Run Command:**
  ```bash
  pip install -r 2_Source_Code/requirements.txt
  python 2_Source_Code/main.py
  ```

## 3. Report (`3_Report/report.html`)
- **Self-contained HTML report** that opens directly in any web browser (Chrome, Edge, Safari, Firefox).
- All graphics (perplexity optimization curve, keyword probability charts, word clouds, document prevalence, and t-SNE 2D cluster projections) are **embedded directly into the HTML**.
- Includes full academic context:
  1. Biological background and research question formulation.
  2. Data collection and extraction protocol.
  3. Preprocessing and LDA modeling methodology.
  4. Perplexity evaluation across $k \in [3, 8]$ identifying optimal $k = 5$.
  5. In-depth biological justification of all 5 clusters answering the research question.
  6. Academic bibliography.
