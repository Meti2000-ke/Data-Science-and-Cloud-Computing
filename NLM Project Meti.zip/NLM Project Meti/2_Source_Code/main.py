"""
Project 3: Bioinformatics Application of NLP for Answering Biological Research Questions

Biological Research Question:
"What are the predominant molecular pathways, tumor microenvironment factors, and biomarkers
driving resistance to immune checkpoint inhibitors (anti-PD-1/CTLA-4) in solid tumors?"

Author: Bioinformatics & NLP Research Team
Deliverables:
  1. Data: 1,000 curated PubMed abstracts (in 1_Data/)
  2. Source Code: This script & analysis_notebook.ipynb (in 2_Source_Code/)
  3. Report: report.html (in 3_Report/)
"""

import os
import re
import json
import string
import time
from typing import List, Dict, Any, Tuple
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.manifold import TSNE
import nltk
from nltk.corpus import stopwords, wordnet
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag, word_tokenize


# Ensure NLTK packages
for res in ['punkt', 'stopwords', 'wordnet', 'omw-1.4', 'averaged_perceptron_tagger']:
    try:
        nltk.download(res, quiet=True)
    except Exception:
        pass


# Domain-generic stop words to remove non-discriminative oncology vocabulary
DOMAIN_STOPWORDS = {
    "study", "studies", "result", "results", "conclusion", "conclusions", "background",
    "method", "methods", "aim", "aims", "objective", "objectives", "finding", "findings",
    "data", "analysis", "analyses", "investigate", "investigated", "demonstrate", "demonstrated",
    "show", "showed", "reveal", "revealed", "indicate", "indicated", "suggest", "suggested",
    "observe", "observed", "report", "reported", "provide", "provided", "perform", "performed",
    "evaluate", "evaluated", "assess", "assessed", "compare", "compared", "author", "authors",
    "significant", "significantly", "increase", "increased", "decrease", "decreased", "associated",
    "level", "levels", "role", "roles", "potential", "critical", "important", "major", "novel",
    "cohort", "sample", "samples", "group", "groups", "year", "years", "number", "numbers",
    "cancer", "cancers", "tumor", "tumors", "tumour", "tumours", "malignancy", "malignant",
    "patient", "patients", "human", "humans", "mouse", "mice", "model", "models", "cell", "cells",
    "tissue", "tissues", "therapy", "therapies", "treatment", "treatments", "treated", "drug", "drugs",
    "immune", "immunity", "immunotherapy", "immunotherapies", "checkpoint", "checkpoints",
    "inhibitor", "inhibitors", "inhibition", "inhibit", "blockade", "blocking", "blocked",
    "resistance", "resistant", "refractory", "response", "responder", "nonresponder", "clinical",
    "trial", "trials", "efficacy", "effective", "outcome", "outcomes", "survival", "prognosis",
    "ici", "icis", "icb", "icbs", "anti", "target", "targets", "targeted", "targeting",
    "mechanism", "mechanisms", "strategy", "strategies", "combination", "combinations",
    "combined", "combine", "approach", "approaches", "advance", "advances", "recent", "recently",
    "emerge", "emerged", "emerging", "discuss", "discussed", "focus", "focuses", "review",
    "overcome", "overcoming", "improve", "improved", "enhance", "enhanced", "promote", "promotes",
    "induce", "induced", "mediate", "mediated", "drive", "drives", "driven", "play", "plays",
    "key", "crucial", "essential", "remain", "remains", "may", "can", "could", "also", "well",
    "however", "furthermore", "moreover", "addition", "additionally", "thus", "therefore",
    "high", "higher", "low", "lower", "use", "uses", "used", "using", "base", "based",
    "type", "types", "death", "program", "antitumor", "activity", "activities",
    "tme", "tumor_microenvironment"
}


class BiologicalNLPPreprocessor:
    """Preprocesses biomedical research abstracts."""

    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        self.stopwords = set(stopwords.words("english")).union(DOMAIN_STOPWORDS)
        self.phrase_map = {
            r"\banti[- ]?pd[- ]?1\b": "anti_pd1",
            r"\banti[- ]?pd[- ]?l1\b": "anti_pdl1",
            r"\banti[- ]?ctla[- ]?4\b": "anti_ctla4",
            r"\bpd[- ]?l1\b": "pdl1",
            r"\bpd[- ]?1\b": "pd1",
            r"\bctla[- ]?4\b": "ctla4",
            r"\bregulatory t cell\w*\b": "treg",
            r"\bmyeloid[- ]derived suppressor cell\w*\b": "mdsc",
            r"\btumor[- ]associated macrophage\w*\b": "tam",
            r"\btransforming growth factor[- ]beta\b": "tgf_beta",
            r"\btgf[- ]?beta\b": "tgf_beta",
            r"\binterferon[- ]gamma\b": "ifn_gamma",
            r"\bifn[- ]?gamma\b": "ifn_gamma",
            r"\bgut microbio\w+\b": "gut_microbiota",
            r"\bcirculating tumor dna\b": "ctdna",
            r"\bnon[- ]small cell lung cancer\b": "nsclc",
            r"\bcolorectal cancer\b": "crc",
            r"\bhepatocellular carcinoma\b": "hcc",
            r"\btriple[- ]negative breast cancer\b": "tnbc"
        }

    def clean_text(self, text: str) -> str:
        text_lower = text.lower()
        for pattern, replacement in self.phrase_map.items():
            text_lower = re.sub(pattern, replacement, text_lower)
        text_lower = re.sub(r"https?://\S+|www\.\S+", " ", text_lower)
        text_lower = re.sub(r"<.*?>", " ", text_lower)
        valid = set(string.ascii_lowercase + string.digits + " _")
        text_clean = "".join([c if c in valid else " " for c in text_lower])
        return re.sub(r"\s+", " ", text_clean).strip()

    def tokenize_and_lemmatize(self, text: str) -> List[str]:
        cleaned = self.clean_text(text)
        tokens = [t for t in word_tokenize(cleaned) if len(t) >= 3 and not t.isdigit()]
        if not tokens:
            return []
        tagged = pos_tag(tokens)
        result = []
        for word, tag in tagged:
            wn_pos = wordnet.VERB if tag.startswith("V") else (wordnet.ADJ if tag.startswith("J") else wordnet.NOUN)
            lemma = self.lemmatizer.lemmatize(word, pos=wn_pos)
            if len(lemma) >= 3 and lemma not in self.stopwords and not lemma.isnumeric():
                result.append(lemma)
        return result


def load_dataset(data_path: str = "../1_Data/pubmed_1000_abstracts.csv") -> pd.DataFrame:
    """Load the 1,000 PubMed abstracts."""
    if not os.path.exists(data_path):
        # Fallback to local data folder if running from root
        fallback = "1_Data/pubmed_1000_abstracts.csv"
        if os.path.exists(fallback):
            data_path = fallback
        else:
            raise FileNotFoundError(f"Dataset not found at {data_path}")
    print(f"Loading dataset from: {data_path}")
    df = pd.read_csv(data_path)
    print(f"Loaded {len(df)} abstracts successfully.")
    return df


def preprocess_corpus(df: pd.DataFrame) -> Tuple[List[str], pd.DataFrame]:
    """Preprocess corpus text."""
    print("Preprocessing abstracts...")
    preprocessor = BiologicalNLPPreprocessor()
    clean_docs = []
    for idx, text in enumerate(df["abstract"].fillna("")):
        tokens = preprocessor.tokenize_and_lemmatize(text)
        clean_docs.append(" ".join(tokens))
    df["clean_abstract"] = clean_docs
    return clean_docs, df


def run_lda(clean_docs: List[str], n_topics: int = 5) -> Tuple[Any, Any, np.ndarray, List[str]]:
    """Build count matrix and fit Latent Dirichlet Allocation."""
    print(f"\nVectorizing text into Count Matrix...")
    vectorizer = CountVectorizer(min_df=3, max_df=0.65, max_features=3000, token_pattern=r"\b[a-zA-Z_]{3,}\b")
    dtm = vectorizer.fit_transform(clean_docs)
    vocab = vectorizer.get_feature_names_out()
    print(f"Document-Term Matrix: {dtm.shape} (Vocabulary: {len(vocab)})")

    print(f"Training LDA Model with k={n_topics} biological clusters...")
    lda = LatentDirichletAllocation(n_components=n_topics, max_iter=40, learning_method="batch", random_state=42, n_jobs=-1)
    doc_topic_dist = lda.fit_transform(dtm)
    perplexity = lda.perplexity(dtm)
    print(f"Model Perplexity: {perplexity:.2f}")

    return lda, vectorizer, doc_topic_dist, vocab


def print_cluster_keywords(lda, vocab, n_top_words: int = 12):
    """Print top keywords for each topic cluster."""
    print("\n" + "="*80)
    print("DISCOVERED BIOLOGICAL CLUSTERS & CHARACTERISTIC KEYWORDS")
    print("="*80)
    for topic_idx, topic in enumerate(lda.components_):
        top_indices = topic.argsort()[::-1][:n_top_words]
        top_words = [vocab[i] for i in top_indices]
        print(f"\nCluster {topic_idx + 1}:")
        print("  Keywords: " + ", ".join(top_words))
    print("\n" + "="*80)


def main():
    print("Starting Project 3 NLP Pipeline...")
    df = load_dataset()
    clean_docs, df = preprocess_corpus(df)
    lda, vectorizer, doc_topic_dist, vocab = run_lda(clean_docs, n_topics=5)
    print_cluster_keywords(lda, vocab)
    print("\nPipeline execution complete! Refer to 3_Report/report.html for detailed justifications.")


if __name__ == "__main__":
    main()
