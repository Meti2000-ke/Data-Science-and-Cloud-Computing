#!/usr/bin/env bash
# ==============================================================================
# Pipeline Execution Wrapper for Linux Ubuntu Environment
# Project: MSc Bioinformatics - Assignment 1
# Author:  Meti Habtamu (ID: GSR/6764/18)
# ==============================================================================

set -euo pipefail

echo "=========================================================="
echo " Starting Podoconiosis RNA-seq Analysis Workflow (Ubuntu)"
echo " Date: $(date)"
echo " Host: $(hostname)"
echo " OS:   $(uname -s -r -m)"
echo "=========================================================="

mkdir -p figures results

if command -v Rscript >/dev/null 2>&1; then
    echo "[1/2] Executing primary R analysis script..."
    Rscript scripts/analyze_podoconiosis.R
else
    echo "[Notice] Rscript not detected in PATH; executing Python pipeline..."
fi

if command -v python3 >/dev/null 2>&1; then
    echo "[2/2] Running Python companion verification..."
    python3 scripts/reproduce_analysis.py
fi

echo "=========================================================="
echo " Pipeline execution complete. All figures generated."
echo "=========================================================="
